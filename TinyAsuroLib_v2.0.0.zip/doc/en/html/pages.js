var pages =
[
    [ "Noteworthy differences", "differences.html", null ],
    [ "Hardware resources in use", "hardware.html", null ],
    [ "Interrupt vectors in use", "interrupts.html", null ],
    [ "Deprecated List", "deprecated.html", null ]
];