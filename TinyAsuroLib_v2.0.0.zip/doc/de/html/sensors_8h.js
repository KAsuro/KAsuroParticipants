var sensors_8h =
[
    [ "LEFT", "sensors_8h.html#a437ef08681e7210d6678427030446a54", null ],
    [ "RIGHT", "sensors_8h.html#a80fb826a684cf3f0d306b22aa100ddac", null ],
    [ "AutoMeasurmentMode_t", "sensors_8h.html#a79f4820891e1a35816f8e8395029ec25", null ],
    [ "SensorInit", "sensors_8h.html#a5b15323dd447e4db7677a19089955913", null ],
    [ "LineData", "sensors_8h.html#a7a732e88bdb1d7dd45e3f9e07b3fa5a7", null ],
    [ "OdometryData", "sensors_8h.html#ae931bad72479894d85052fce9f4491da", null ],
    [ "OdometrieData", "sensors_8h.html#a22d3fd3d32ff70d9e0afa646a420a9f7", null ],
    [ "BatteryVoltage", "sensors_8h.html#a48f064c20b23e7d3b049859aa1913310", null ],
    [ "SensorConfigAutomode", "sensors_8h.html#af97e100f0689f33067132792351e5cf1", null ],
    [ "odoData", "sensors_8h.html#aeea05a42bf5df828380fdc9253af998f", null ],
    [ "odoDataUpdated", "sensors_8h.html#a3463504a9988396fd366bf59168b9e84", null ],
    [ "lineData", "sensors_8h.html#a20fb6a04e4d902539c0600fcc02cb39d", null ],
    [ "lineDataUpdated", "sensors_8h.html#a63a0a76caf3bc270da26a8b08491f5f2", null ],
    [ "ADCISRHook", "sensors_8h.html#a7f6ab408b477700ccb3c01ba61cfbf35", null ]
];