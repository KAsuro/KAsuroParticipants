var time_8c =
[
    [ "Timer2Init", "time_8c.html#a21b35a563150d94b502ad806d1151473", null ],
    [ "ISR", "time_8c.html#a7cfcbe42bd266750aeb6e5d71e5ea479", null ],
    [ "sleep", "time_8c.html#a2477e3a9d3cad81eb375f536b26cac37", null ],
    [ "sleepUntilInterrupt", "time_8c.html#aaacb05e793f1e9692d30f62c6fdc871c", null ],
    [ "tick36kHz", "time_8c.html#acb5a21cd2cc83fe4c186fa03551e89fa", null ]
];