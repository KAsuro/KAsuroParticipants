var dirs =
[
    [ "libtinyasuro", "dir_0db316a1853ba5bdbeb25ba0e10d2b05.html", "dir_0db316a1853ba5bdbeb25ba0e10d2b05" ],
    [ "tinyasuroboot", "dir_e85d5aaae8515b656cf7ffd1a1df428f.html", null ]
];