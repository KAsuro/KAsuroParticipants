var time_8h =
[
    [ "Sleep", "time_8h.html#a43984bdff96decf76fb0b2b72c4cee25", null ],
    [ "Msleep", "time_8h.html#a77e38eafeb56d9f2f687ee40cbe3a696", null ],
    [ "SleepUntilInterrupt", "time_8h.html#a99f12ef12d5f29479528ab7c2a325c5c", null ],
    [ "TIMER2_CLOCK_OUT_ENABLE", "time_8h.html#a1087cc0bd556ab913b512fd64bc08619", null ],
    [ "TIMER2_CLOCK_OUT_DISABLE", "time_8h.html#abf252a8953b5194621c842453a4c07e7", null ],
    [ "Timer2Init", "time_8h.html#a21b35a563150d94b502ad806d1151473", null ],
    [ "sleep", "time_8h.html#a2477e3a9d3cad81eb375f536b26cac37", null ],
    [ "sleepUntilInterrupt", "time_8h.html#aaacb05e793f1e9692d30f62c6fdc871c", null ],
    [ "msleep", "time_8h.html#a07ee9a8b3949891833e5bb1d893c7f83", null ],
    [ "tick36kHz", "time_8h.html#acb5a21cd2cc83fe4c186fa03551e89fa", null ],
    [ "Timer2ISRHook", "time_8h.html#a016c02aaed558dc0b882137382d11b1c", null ]
];