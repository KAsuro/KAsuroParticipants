var sensors_8c =
[
    [ "AUTOMODE_CH_ODO_RIGHT", "sensors_8c.html#a144820f33c0919988cb39fdc1e28dc86", null ],
    [ "AUTOMODE_CH_ODO_LEFT", "sensors_8c.html#a0de170295c9165ff9d2f84c027877d7d", null ],
    [ "AUTOMODE_CH_IR_RIGHT", "sensors_8c.html#a91c609d458c05a145653cd7a45fadb8a", null ],
    [ "AUTOMODE_CH_IR_LEFT", "sensors_8c.html#ae2033444c2df1ac6ed3f5658cfc321c2", null ],
    [ "AUTOMODE_ADC_CH", "sensors_8c.html#a2417d616af8c5a072597c7aafd33aec7", null ],
    [ "SensorInit", "sensors_8c.html#a5b15323dd447e4db7677a19089955913", null ],
    [ "SensorConfigAutomode", "sensors_8c.html#af97e100f0689f33067132792351e5cf1", null ],
    [ "LineData", "sensors_8c.html#a7a732e88bdb1d7dd45e3f9e07b3fa5a7", null ],
    [ "OdometryData", "sensors_8c.html#ae931bad72479894d85052fce9f4491da", null ],
    [ "OdometrieData", "sensors_8c.html#af6a13e23f06c42d6b083af258333bc7b", null ],
    [ "BatteryVoltage", "sensors_8c.html#add413901c3c54f06ceae49fb0b903f00", null ],
    [ "ISR", "sensors_8c.html#a05c2e5b588ced1cd7312f5b0edc5b295", null ],
    [ "amMode", "sensors_8c.html#a712cf13aff5b9c8b3edc7ec5959c8772", null ],
    [ "odoData", "sensors_8c.html#aeea05a42bf5df828380fdc9253af998f", null ],
    [ "odoDataUpdated", "sensors_8c.html#a3463504a9988396fd366bf59168b9e84", null ],
    [ "lineData", "sensors_8c.html#a20fb6a04e4d902539c0600fcc02cb39d", null ],
    [ "lineDataUpdated", "sensors_8c.html#a63a0a76caf3bc270da26a8b08491f5f2", null ]
];