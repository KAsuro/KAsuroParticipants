var config_8h =
[
    [ "OVERRIDE_BAUD", "config_8h.html#a203f95f34faa7bfce602aa3f8101687b", null ],
    [ "BAUD", "config_8h.html#a62634036639f88eece6fbf226b45f84b", null ],
    [ "SWITCH_FACTOR", "config_8h.html#a3bfa0d6d715070dcfd79e9141d3ccc41", null ],
    [ "INTERNAL_BATTERY_MEASURMENT", "config_8h.html#acdb9176b9d802c90d313ae5b373d6e07", null ],
    [ "BATTERY_CALIBRATION_FACTOR", "config_8h.html#a80cf16af6add11c88d34bd63d5ca8ba7", null ],
    [ "ODO_EDGE_THRESHOLD", "config_8h.html#a7f3ba2eba82fdce2a08ad283017f998a", null ],
    [ "ENC_MM_PER_TICK", "config_8h.html#a830db44c8ffb85e3a6ceeba7c923f277", null ],
    [ "ENC_TURN_TICKS_PER_360_DEGREE", "config_8h.html#a4d307fb36afe537ed4a03a6aed85df40", null ],
    [ "ENCODER_MOVEMENT_DELTA_LIMIT", "config_8h.html#ae600e0e9c56862903e8829f3fb96c74b", null ],
    [ "ENCODER_MOVEMENT_STEP", "config_8h.html#a90c47cd2b7b3ff330c21f851115b85ab", null ]
];