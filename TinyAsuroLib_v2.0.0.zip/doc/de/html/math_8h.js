var math_8h =
[
    [ "add8u_sat", "math_8h.html#a7769cd747dae4c3b219bb7e57de45b71", null ],
    [ "sub8u_sat", "math_8h.html#a97a605c248a5d5f1617cdc1d9e470713", null ]
];