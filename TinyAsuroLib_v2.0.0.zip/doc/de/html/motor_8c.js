var motor_8c =
[
    [ "PWM", "motor_8c.html#a538e3ec60828cfabae7e3011d73d2093", null ],
    [ "RIGHT_DIR", "motor_8c.html#a280580881770229c533faab28f235a05", null ],
    [ "LEFT_DIR", "motor_8c.html#a748e2ff253570331d3cd8f51ccc17f03", null ],
    [ "MotorInit", "motor_8c.html#a03fa9e7b83025b081d85ee7cc8e0ad10", null ],
    [ "MotorDir", "motor_8c.html#a15bbe01030266051426e368619d478ba", null ],
    [ "MotorSpeed", "motor_8c.html#ade3517edc7d0f314e684ae9de40bcefd", null ]
];