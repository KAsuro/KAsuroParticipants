var misc_8h =
[
    [ "USED", "misc_8h.html#abcd0a22ee4346cad5706adb6d2119429", null ],
    [ "UNUSED", "misc_8h.html#addf5ec070e9499d36b7f2009ce736076", null ],
    [ "MAIN", "misc_8h.html#a34b04bd23b07b485921a728ad0805ac4", null ],
    [ "NAKED", "misc_8h.html#a7a18c4884994b9b520ae535b6d9579d3", null ],
    [ "ALWAYS_INLINE", "misc_8h.html#aa1dec568e79152c892dcf63f445cbd7a", null ],
    [ "NOINLINE", "misc_8h.html#a1b173d22e57d9395897acbd8de62d505", null ],
    [ "ON_CLEANUP", "misc_8h.html#ad9ebffa94659cb789119653eb4c22d0e", null ],
    [ "CONST", "misc_8h.html#a0c33b494a68ce28497e7ce8e5e95feff", null ],
    [ "PURE", "misc_8h.html#acd42770aecb025cfac170d4d3ace4544", null ],
    [ "ALIAS", "misc_8h.html#a2dd79b830902149e2594aa3c7a142c0e", null ],
    [ "DEPRECATED", "misc_8h.html#ad034ea058031ed95e52d3bac1743640a", null ],
    [ "WARNING", "misc_8h.html#a5eb81717658ef959b101d61d2fa2cce7", null ],
    [ "ERROR", "misc_8h.html#a435175024ad996b2a45d734fa9eea0e3", null ],
    [ "UNION_CAST", "misc_8h.html#ab2d4fd0ee606d64d8f063455c3fcb45a", null ]
];