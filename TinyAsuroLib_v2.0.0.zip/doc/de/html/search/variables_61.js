var searchData=
[
  ['adcisrhook',['ADCISRHook',['../sensors_8h.html#a7f6ab408b477700ccb3c01ba61cfbf35',1,'sensors.h']]],
  ['ammode',['amMode',['../sensors_8c.html#a712cf13aff5b9c8b3edc7ec5959c8772',1,'sensors.c']]]
];
