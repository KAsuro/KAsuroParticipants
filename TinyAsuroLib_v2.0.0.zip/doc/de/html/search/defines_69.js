var searchData=
[
  ['internal_5fbattery_5fmeasurment',['INTERNAL_BATTERY_MEASURMENT',['../config_8h.html#acdb9176b9d802c90d313ae5b373d6e07',1,'config.h']]],
  ['ir_5ftx_5fout',['IR_TX_OUT',['../uart_8c.html#a1a511ae414b99ad4f7c305f96cdb66c1',1,'uart.c']]]
];
