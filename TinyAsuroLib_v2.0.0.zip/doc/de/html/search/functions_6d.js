var searchData=
[
  ['motordir',['MotorDir',['../motor_8h.html#a15bbe01030266051426e368619d478ba',1,'MotorDir(const uint8_t left_dir, const uint8_t right_dir):&#160;motor.c'],['../motor_8c.html#a15bbe01030266051426e368619d478ba',1,'MotorDir(const uint8_t left_dir, const uint8_t right_dir):&#160;motor.c']]],
  ['motorinit',['MotorInit',['../motor_8h.html#a03fa9e7b83025b081d85ee7cc8e0ad10',1,'MotorInit(void):&#160;motor.c'],['../motor_8c.html#a03fa9e7b83025b081d85ee7cc8e0ad10',1,'MotorInit(void):&#160;motor.c']]],
  ['motorspeed',['MotorSpeed',['../motor_8h.html#ade3517edc7d0f314e684ae9de40bcefd',1,'MotorSpeed(const uint8_t left_speed, const uint8_t right_speed):&#160;motor.c'],['../motor_8c.html#ade3517edc7d0f314e684ae9de40bcefd',1,'MotorSpeed(const uint8_t left_speed, const uint8_t right_speed):&#160;motor.c']]],
  ['msleep',['msleep',['../time_8h.html#a07ee9a8b3949891833e5bb1d893c7f83',1,'time.h']]]
];
