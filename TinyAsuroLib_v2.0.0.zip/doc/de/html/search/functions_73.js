var searchData=
[
  ['sensorconfigautomode',['SensorConfigAutomode',['../sensors_8h.html#af97e100f0689f33067132792351e5cf1',1,'SensorConfigAutomode(const AutoMeasurmentMode_t mode):&#160;sensors.c'],['../sensors_8c.html#af97e100f0689f33067132792351e5cf1',1,'SensorConfigAutomode(const AutoMeasurmentMode_t mode):&#160;sensors.c']]],
  ['sensorinit',['SensorInit',['../sensors_8h.html#a5b15323dd447e4db7677a19089955913',1,'SensorInit(void):&#160;sensors.c'],['../sensors_8c.html#a5b15323dd447e4db7677a19089955913',1,'SensorInit(void):&#160;sensors.c']]],
  ['serinit',['SerInit',['../uart_8h.html#a356ee9f9d5bf2a8aa5459e18283fda91',1,'SerInit(void):&#160;uart.c'],['../uart_8c.html#a356ee9f9d5bf2a8aa5459e18283fda91',1,'SerInit(void):&#160;uart.c']]],
  ['serread',['SerRead',['../uart_8h.html#a007c6252787f5a8b98d9a9633dcb9945',1,'SerRead(char *const data, const uint8_t length, uint16_t timeout):&#160;uart.c'],['../uart_8c.html#a007c6252787f5a8b98d9a9633dcb9945',1,'SerRead(char *const data, const uint8_t length, uint16_t timeout):&#160;uart.c']]],
  ['serwrite',['SerWrite',['../uart_8h.html#aa0f628738cf535cec1a6c26288c95923',1,'SerWrite(char *data, uint8_t length):&#160;uart.c'],['../uart_8c.html#aa0f628738cf535cec1a6c26288c95923',1,'SerWrite(char *data, uint8_t length):&#160;uart.c']]],
  ['sleep',['sleep',['../time_8h.html#a2477e3a9d3cad81eb375f536b26cac37',1,'sleep(uint8_t timer36kHz_ticks):&#160;time.c'],['../time_8c.html#a2477e3a9d3cad81eb375f536b26cac37',1,'sleep(uint8_t timer36kHz_ticks):&#160;time.c']]],
  ['sleepuntilinterrupt',['sleepUntilInterrupt',['../time_8h.html#aaacb05e793f1e9692d30f62c6fdc871c',1,'sleepUntilInterrupt(void):&#160;time.c'],['../time_8c.html#aaacb05e793f1e9692d30f62c6fdc871c',1,'sleepUntilInterrupt(void):&#160;time.c']]],
  ['statusled',['StatusLED',['../led_8h.html#a2b5bc121ddd4f3af5c4d2ce09c73e70b',1,'StatusLED(const uint8_t color):&#160;led.c'],['../led_8c.html#a2b5bc121ddd4f3af5c4d2ce09c73e70b',1,'StatusLED(const uint8_t color):&#160;led.c']]],
  ['sub8u_5fsat',['sub8u_sat',['../math_8h.html#a97a605c248a5d5f1617cdc1d9e470713',1,'math.h']]],
  ['switchinit',['SwitchInit',['../switches_8h.html#a0f674ea092ae368ce3d994d179c91a24',1,'SwitchInit(void):&#160;switches.c'],['../switches_8c.html#a0f674ea092ae368ce3d994d179c91a24',1,'SwitchInit(void):&#160;switches.c']]],
  ['switchinterruptdisable',['SwitchInterruptDisable',['../switches_8h.html#a434762fea9c659bdcb8bb6c9b67ec396',1,'SwitchInterruptDisable(void):&#160;switches.c'],['../switches_8c.html#a434762fea9c659bdcb8bb6c9b67ec396',1,'SwitchInterruptDisable(void):&#160;switches.c']]],
  ['switchinterruptenable',['SwitchInterruptEnable',['../switches_8h.html#adef7d0d969cec58f861159c97010282d',1,'SwitchInterruptEnable(void):&#160;switches.c'],['../switches_8c.html#adef7d0d969cec58f861159c97010282d',1,'SwitchInterruptEnable(void):&#160;switches.c']]]
];
