var searchData=
[
  ['pure',['PURE',['../misc_8h.html#acd42770aecb025cfac170d4d3ace4544',1,'misc.h']]],
  ['pwm',['PWM',['../motor_8c.html#a538e3ec60828cfabae7e3011d73d2093',1,'motor.c']]]
];
