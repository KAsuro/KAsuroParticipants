var searchData=
[
  ['adcinit',['ADCInit',['../adc_8h.html#a39150f192703c8fc5f1885bc21deee7f',1,'ADCInit(void):&#160;adc.c'],['../adc_8c.html#a39150f192703c8fc5f1885bc21deee7f',1,'ADCInit(void):&#160;adc.c']]],
  ['adcinterruptdisable',['ADCInterruptDisable',['../adc_8h.html#acb00acd7a95bea215369de562e9a18f0',1,'ADCInterruptDisable(void):&#160;adc.c'],['../adc_8c.html#acb00acd7a95bea215369de562e9a18f0',1,'ADCInterruptDisable(void):&#160;adc.c']]],
  ['adcinterruptenable',['ADCInterruptEnable',['../adc_8h.html#a6a8d812c1d6a5769e6664157e38d1982',1,'ADCInterruptEnable(const uint8_t channel):&#160;adc.c'],['../adc_8c.html#a6a8d812c1d6a5769e6664157e38d1982',1,'ADCInterruptEnable(const uint8_t channel):&#160;adc.c']]],
  ['adcmeasure',['ADCMeasure',['../adc_8h.html#a3b6afebcfa785ed99bf93614d4cde530',1,'ADCMeasure(void):&#160;adc.c'],['../adc_8c.html#a3b6afebcfa785ed99bf93614d4cde530',1,'ADCMeasure(void):&#160;adc.c']]],
  ['adcselectchannel',['ADCSelectChannel',['../adc_8h.html#af543d543acc739b441f13436933f34e9',1,'ADCSelectChannel(const uint8_t channel):&#160;adc.c'],['../adc_8c.html#af543d543acc739b441f13436933f34e9',1,'ADCSelectChannel(const uint8_t channel):&#160;adc.c']]],
  ['add8u_5fsat',['add8u_sat',['../math_8h.html#a7769cd747dae4c3b219bb7e57de45b71',1,'math.h']]]
];
