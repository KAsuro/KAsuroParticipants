var searchData=
[
  ['odometriedata',['OdometrieData',['../sensors_8h.html#a22d3fd3d32ff70d9e0afa646a420a9f7',1,'OdometrieData(uint16_t *const data):&#160;sensors.h'],['../sensors_8c.html#af6a13e23f06c42d6b083af258333bc7b',1,'OdometrieData(uint16_t *const data) ALIAS(&quot;OdometryData&quot;):&#160;sensors.c']]],
  ['odometrydata',['OdometryData',['../sensors_8h.html#ae931bad72479894d85052fce9f4491da',1,'OdometryData(uint16_t *const data):&#160;sensors.c'],['../sensors_8c.html#ae931bad72479894d85052fce9f4491da',1,'OdometryData(uint16_t *const data):&#160;sensors.c']]]
];
