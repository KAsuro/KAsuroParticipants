var searchData=
[
  ['naked',['NAKED',['../misc_8h.html#a7a18c4884994b9b520ae535b6d9579d3',1,'misc.h']]],
  ['noinline',['NOINLINE',['../misc_8h.html#a1b173d22e57d9395897acbd8de62d505',1,'misc.h']]]
];
