var searchData=
[
  ['sensors_2ec',['sensors.c',['../sensors_8c.html',1,'']]],
  ['sensors_2eh',['sensors.h',['../sensors_8h.html',1,'']]],
  ['switches_2ec',['switches.c',['../switches_8c.html',1,'']]],
  ['switches_2eh',['switches.h',['../switches_8h.html',1,'']]]
];
