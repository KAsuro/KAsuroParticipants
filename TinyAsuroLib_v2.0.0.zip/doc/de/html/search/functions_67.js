var searchData=
[
  ['goturn',['GoTurn',['../encoder_8h.html#a14091233a139a450adb0577fcb97bba3',1,'GoTurn(int16_t distance, int16_t degree, uint8_t speed):&#160;encoder.c'],['../encoder_8c.html#a14091233a139a450adb0577fcb97bba3',1,'GoTurn(int16_t distance, int16_t degree, uint8_t speed):&#160;encoder.c']]]
];
