var searchData=
[
  ['right',['right',['../struct_encoder_ticks__t.html#a82f2d97b59b664e0a6b9ab752738db23',1,'EncoderTicks_t::right()'],['../struct_sensor_values__t.html#a61938d8fca0e953d39df2d9e06f55b10',1,'SensorValues_t::right()']]]
];
