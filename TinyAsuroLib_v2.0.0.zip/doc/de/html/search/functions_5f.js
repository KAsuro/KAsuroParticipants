var searchData=
[
  ['_5f_5fadcblockenter',['__ADCBlockEnter',['../adc_8c.html#a247b37106cff86ae4f45c0f016ffa50d',1,'adc.c']]],
  ['_5f_5fadcblockleave',['__ADCBlockLeave',['../adc_8c.html#aff69faa1de1f2ad602f94f8057b8fa0c',1,'adc.c']]]
];
