var searchData=
[
  ['ododata',['odoData',['../sensors_8h.html#aeea05a42bf5df828380fdc9253af998f',1,'odoData():&#160;sensors.c'],['../sensors_8c.html#aeea05a42bf5df828380fdc9253af998f',1,'odoData():&#160;sensors.c']]],
  ['ododataupdated',['odoDataUpdated',['../sensors_8h.html#a3463504a9988396fd366bf59168b9e84',1,'odoDataUpdated():&#160;sensors.c'],['../sensors_8c.html#a3463504a9988396fd366bf59168b9e84',1,'odoDataUpdated():&#160;sensors.c']]]
];
