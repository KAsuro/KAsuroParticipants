var searchData=
[
  ['init',['Init',['../asuro_8h.html#a7ce0a14b6e7779fbb2d9a05333792c41',1,'Init(void):&#160;asuro.c'],['../asuro_8c.html#a7ce0a14b6e7779fbb2d9a05333792c41',1,'Init(void):&#160;asuro.c']]],
  ['isr',['ISR',['../sensors_8c.html#a05c2e5b588ced1cd7312f5b0edc5b295',1,'ISR(ADC_vect):&#160;sensors.c'],['../switches_8c.html#a22acfb428840c6d9aa212764589cf6c6',1,'ISR(INT1_vect):&#160;switches.c'],['../time_8c.html#a7cfcbe42bd266750aeb6e5d71e5ea479',1,'ISR(TIMER2_OVF_vect):&#160;time.c']]]
];
