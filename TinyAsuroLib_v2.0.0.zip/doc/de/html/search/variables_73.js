var searchData=
[
  ['switch_5fevent',['switch_event',['../switches_8h.html#a095e4a5b222477fc19f533d9350a5ba8',1,'switch_event():&#160;switches.c'],['../switches_8c.html#a095e4a5b222477fc19f533d9350a5ba8',1,'switch_event():&#160;switches.c']]],
  ['switchisrhook',['SwitchISRHook',['../switches_8h.html#a0a001cde623f5b0e6cfca680a79a22c6',1,'switches.h']]]
];
