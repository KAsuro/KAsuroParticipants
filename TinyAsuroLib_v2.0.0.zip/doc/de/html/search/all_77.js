var searchData=
[
  ['warning',['WARNING',['../misc_8h.html#a5eb81717658ef959b101d61d2fa2cce7',1,'misc.h']]]
];
