var searchData=
[
  ['pollswitch',['PollSwitch',['../switches_8h.html#a5d14a93c00851af7ed7826ae66b24ee3',1,'PollSwitch(void):&#160;switches.c'],['../switches_8c.html#a5d14a93c00851af7ed7826ae66b24ee3',1,'PollSwitch(void):&#160;switches.c']]]
];
