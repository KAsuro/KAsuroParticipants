var searchData=
[
  ['tick36khz',['tick36kHz',['../time_8h.html#acb5a21cd2cc83fe4c186fa03551e89fa',1,'tick36kHz():&#160;time.c'],['../time_8c.html#acb5a21cd2cc83fe4c186fa03551e89fa',1,'tick36kHz():&#160;time.c']]],
  ['timer2isrhook',['Timer2ISRHook',['../time_8h.html#a016c02aaed558dc0b882137382d11b1c',1,'time.h']]]
];
