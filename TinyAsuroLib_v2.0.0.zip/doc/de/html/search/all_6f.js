var searchData=
[
  ['odo_5fedge_5fthreshold',['ODO_EDGE_THRESHOLD',['../config_8h.html#a7f3ba2eba82fdce2a08ad283017f998a',1,'config.h']]],
  ['ododata',['odoData',['../sensors_8h.html#aeea05a42bf5df828380fdc9253af998f',1,'odoData():&#160;sensors.c'],['../sensors_8c.html#aeea05a42bf5df828380fdc9253af998f',1,'odoData():&#160;sensors.c']]],
  ['ododataupdated',['odoDataUpdated',['../sensors_8h.html#a3463504a9988396fd366bf59168b9e84',1,'odoDataUpdated():&#160;sensors.c'],['../sensors_8c.html#a3463504a9988396fd366bf59168b9e84',1,'odoDataUpdated():&#160;sensors.c']]],
  ['odometrie_5fled',['ODOMETRIE_LED',['../led_8h.html#a176882b8d1388d28d08cfd08e09f7c42',1,'led.h']]],
  ['odometrie_5fled_5foff',['ODOMETRIE_LED_OFF',['../led_8h.html#a5aa3a99bce2bd9bf92096dbf501df692',1,'led.h']]],
  ['odometrie_5fled_5fon',['ODOMETRIE_LED_ON',['../led_8h.html#a3983a1bdfef5aa05a4b05899af5c809f',1,'led.h']]],
  ['odometriedata',['OdometrieData',['../sensors_8h.html#a22d3fd3d32ff70d9e0afa646a420a9f7',1,'OdometrieData(uint16_t *const data):&#160;sensors.h'],['../sensors_8c.html#af6a13e23f06c42d6b083af258333bc7b',1,'OdometrieData(uint16_t *const data) ALIAS(&quot;OdometryData&quot;):&#160;sensors.c']]],
  ['odometry_5fled',['ODOMETRY_LED',['../led_8h.html#ad9e9b3a62aa2af056aa91509d449bdff',1,'led.h']]],
  ['odometry_5fled_5foff',['ODOMETRY_LED_OFF',['../led_8h.html#a7d624ba3ea57797d51ee6c266e0e5bd0',1,'led.h']]],
  ['odometry_5fled_5fon',['ODOMETRY_LED_ON',['../led_8h.html#a23f87f1ab8611cbe135e05b114788213',1,'led.h']]],
  ['odometrydata',['OdometryData',['../sensors_8h.html#ae931bad72479894d85052fce9f4491da',1,'OdometryData(uint16_t *const data):&#160;sensors.c'],['../sensors_8c.html#ae931bad72479894d85052fce9f4491da',1,'OdometryData(uint16_t *const data):&#160;sensors.c']]],
  ['off',['OFF',['../led_8h.html#a29e413f6725b2ba32d165ffaa35b01e5',1,'led.h']]],
  ['on',['ON',['../led_8h.html#ad76d1750a6cdeebd506bfcd6752554d2',1,'led.h']]],
  ['on_5fcleanup',['ON_CLEANUP',['../misc_8h.html#ad9ebffa94659cb789119653eb4c22d0e',1,'misc.h']]],
  ['override_5fbaud',['OVERRIDE_BAUD',['../config_8h.html#a203f95f34faa7bfce602aa3f8101687b',1,'config.h']]]
];
