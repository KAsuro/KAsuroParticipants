var adc_8c =
[
    [ "ADCOff", "adc_8c.html#a3abb546aa5b2f98a735c9e5dc09e0c47", null ],
    [ "disableADCOnRefChange", "adc_8c.html#aa3770aa08a0a7d0d73bb55275652e0f6", null ],
    [ "ADCInit", "adc_8c.html#a39150f192703c8fc5f1885bc21deee7f", null ],
    [ "__ADCBlockEnter", "adc_8c.html#a247b37106cff86ae4f45c0f016ffa50d", null ],
    [ "__ADCBlockLeave", "adc_8c.html#aff69faa1de1f2ad602f94f8057b8fa0c", null ],
    [ "ADCSelectChannel", "adc_8c.html#af543d543acc739b441f13436933f34e9", null ],
    [ "ADCMeasure", "adc_8c.html#a3b6afebcfa785ed99bf93614d4cde530", null ],
    [ "ADCInterruptEnable", "adc_8c.html#a6a8d812c1d6a5769e6664157e38d1982", null ],
    [ "ADCInterruptDisable", "adc_8c.html#acb00acd7a95bea215369de562e9a18f0", null ],
    [ "old_channel", "adc_8c.html#a0601715a617d56ffbd11f06109a12e25", null ]
];