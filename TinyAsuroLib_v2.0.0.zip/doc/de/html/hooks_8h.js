var hooks_8h =
[
    [ "TIMER2_ISR_HOOK_ENABLE", "hooks_8h.html#a8dbd105c15c3eed8388464d7be3c2f38", null ],
    [ "ADC_ISR_HOOK_ENABLE", "hooks_8h.html#a72be15fa0c3d3707c1135cacdc3af804", null ],
    [ "SWITCH_ISR_HOOK_ENABLE", "hooks_8h.html#aa41a82af6f6372f9ea1702a1e34b6374", null ],
    [ "ISRHookFunc_t", "hooks_8h.html#a4e99fd68ad8bb32e1643fd548f450b70", null ]
];