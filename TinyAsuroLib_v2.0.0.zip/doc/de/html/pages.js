var pages =
[
    [ "Besonderheiten/Unterschiede", "differences.html", null ],
    [ "Genutzte Hardwareressourcen", "hardware.html", null ],
    [ "Verwendete Interrupts", "interrupts.html", null ],
    [ "Veraltete Elemente", "deprecated.html", null ]
];