var struct_sensor_values__t =
[
    [ "right", "struct_sensor_values__t.html#a61938d8fca0e953d39df2d9e06f55b10", null ],
    [ "left", "struct_sensor_values__t.html#a70cfd618738e7ccc6476c05b5ec2490e", null ]
];