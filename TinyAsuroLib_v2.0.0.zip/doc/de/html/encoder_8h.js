var encoder_8h =
[
    [ "Go", "encoder_8h.html#a3235d3952c9fdc085d027a48b895e72a", null ],
    [ "Turn", "encoder_8h.html#ad75fc80537113bbf229e230c5f65669d", null ],
    [ "EncoderInit", "encoder_8h.html#a80ec2c177aa9c2636f797ca881381827", null ],
    [ "EncoderPoll", "encoder_8h.html#a90d26c7c902d6b59f5a6dc484641454a", null ],
    [ "EncoderReset", "encoder_8h.html#a18dbe65842a6a727d3c3873938b7c0e4", null ],
    [ "GoTurn", "encoder_8h.html#a14091233a139a450adb0577fcb97bba3", null ],
    [ "EncoderMovementReset", "encoder_8h.html#a913ede697f577a134d678c96b3fce072", null ],
    [ "EncoderMovementSetSpeed", "encoder_8h.html#a657fa55615c1aaf3d83f5ca21cdf3188", null ],
    [ "EncoderMovementPoll", "encoder_8h.html#a37cb1c9808dd557dca2b12f5beab03d7", null ],
    [ "encoderTicks", "encoder_8h.html#a33afb0d05dc053abb3ac739835e90a0f", null ]
];