var switches_8h =
[
    [ "SWITCH_1", "switches_8h.html#afc718c1fcfcf5d762545260289674333", null ],
    [ "SWITCH_2", "switches_8h.html#a62b9d54211060aac86c0ca9b02f7331e", null ],
    [ "SWITCH_3", "switches_8h.html#a760f4fa2340ec8b807fea30119915efa", null ],
    [ "SWITCH_4", "switches_8h.html#a083e2bd040ccdbc6514e13b876ff20f7", null ],
    [ "SWITCH_5", "switches_8h.html#ada58a6eb536d60022c9e42e96f77768f", null ],
    [ "SWITCH_6", "switches_8h.html#a49ee4a35e8c787e63a0be16f5d524d9d", null ],
    [ "SwitchInit", "switches_8h.html#a0f674ea092ae368ce3d994d179c91a24", null ],
    [ "PollSwitch", "switches_8h.html#a5d14a93c00851af7ed7826ae66b24ee3", null ],
    [ "SwitchInterruptEnable", "switches_8h.html#adef7d0d969cec58f861159c97010282d", null ],
    [ "SwitchInterruptDisable", "switches_8h.html#a434762fea9c659bdcb8bb6c9b67ec396", null ],
    [ "switch_event", "switches_8h.html#a095e4a5b222477fc19f533d9350a5ba8", null ],
    [ "SwitchISRHook", "switches_8h.html#a0a001cde623f5b0e6cfca680a79a22c6", null ]
];