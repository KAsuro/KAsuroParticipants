var struct_encoder_ticks__t =
[
    [ "left", "struct_encoder_ticks__t.html#a1a004e32565c228c2e85b35a469d5145", null ],
    [ "right", "struct_encoder_ticks__t.html#a82f2d97b59b664e0a6b9ab752738db23", null ]
];