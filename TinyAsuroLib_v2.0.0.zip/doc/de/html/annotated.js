var annotated =
[
    [ "EncoderTicks_t", "struct_encoder_ticks__t.html", "struct_encoder_ticks__t" ],
    [ "SensorValues_t", "struct_sensor_values__t.html", "struct_sensor_values__t" ]
];