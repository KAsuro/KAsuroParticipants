var encoder_8c =
[
    [ "ENC_DIVIDER", "encoder_8c.html#a205bdb02f599f635d7c064d62b420159", null ],
    [ "ENC_GO_FACTOR", "encoder_8c.html#ad4195c18fce5d751a3c6deec8aefcb5a", null ],
    [ "ENC_TURN_FACTOR", "encoder_8c.html#a92011f919bb88c5d626041af9bda95e2", null ],
    [ "EncoderInit", "encoder_8c.html#a80ec2c177aa9c2636f797ca881381827", null ],
    [ "EncoderPoll", "encoder_8c.html#a90d26c7c902d6b59f5a6dc484641454a", null ],
    [ "EncoderReset", "encoder_8c.html#a18dbe65842a6a727d3c3873938b7c0e4", null ],
    [ "GoTurn", "encoder_8c.html#a14091233a139a450adb0577fcb97bba3", null ],
    [ "EncoderMovementReset", "encoder_8c.html#a913ede697f577a134d678c96b3fce072", null ],
    [ "EncoderMovementSetSpeed", "encoder_8c.html#a657fa55615c1aaf3d83f5ca21cdf3188", null ],
    [ "EncoderMovementPoll", "encoder_8c.html#a37cb1c9808dd557dca2b12f5beab03d7", null ],
    [ "reference", "encoder_8c.html#a87a17d59232799bb08bdab7777d65f2f", null ],
    [ "last_state", "encoder_8c.html#aac5edbb61018a3350932c4f662b914ee", null ],
    [ "encoderTicks", "encoder_8c.html#a33afb0d05dc053abb3ac739835e90a0f", null ],
    [ "leftMovementSpeed", "encoder_8c.html#a11a071fcb12d5e1d1fafa1562939ba85", null ],
    [ "rightMovementSpeed", "encoder_8c.html#a66904d67360e38affe815bcee23f1b4a", null ],
    [ "deltaMovementSpeed", "encoder_8c.html#ad43ab3f3092e863c601afab90837774b", null ]
];