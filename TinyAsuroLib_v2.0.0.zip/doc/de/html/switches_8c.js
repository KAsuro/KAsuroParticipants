var switches_8c =
[
    [ "SWITCHES", "switches_8c.html#a982e6a0873b4ed1df90a1f963e49a551", null ],
    [ "SWITCH_ON", "switches_8c.html#a1276efb1a647e40b3bb0f09234e8b682", null ],
    [ "SWITCH_OFF", "switches_8c.html#ab1a7842d730e5d25b9b8e0a5e1421e12", null ],
    [ "SWITCH_OUTPUT", "switches_8c.html#ab363ae9ca3ee14d72c754b75f577d54d", null ],
    [ "SWITCH_INPUT", "switches_8c.html#a8ed1c5f3ba42ab63e7b0272304df2f9f", null ],
    [ "SWITCH_INTF_CLEAR", "switches_8c.html#af3e08ba76291e03d235d2efd418b9cb0", null ],
    [ "SwitchInit", "switches_8c.html#a0f674ea092ae368ce3d994d179c91a24", null ],
    [ "PollSwitch", "switches_8c.html#a5d14a93c00851af7ed7826ae66b24ee3", null ],
    [ "SwitchInterruptEnable", "switches_8c.html#adef7d0d969cec58f861159c97010282d", null ],
    [ "SwitchInterruptDisable", "switches_8c.html#a434762fea9c659bdcb8bb6c9b67ec396", null ],
    [ "ISR", "switches_8c.html#a22acfb428840c6d9aa212764589cf6c6", null ],
    [ "switch_event", "switches_8c.html#a095e4a5b222477fc19f533d9350a5ba8", null ]
];